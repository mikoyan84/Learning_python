import com.dreamsecurity.arctrapi.ARCTRInteract;
import com.dreamsecurity.arctrapi.IARCTRInteract;


public class UsageSample {
	public static void main(String[] args){
		IARCTRInteract obj = new ARCTRInteract();
		obj.setsTargetIp( "127.0.0.1" );
		obj.setiTargetPort( 9510);
		try{
			String sClip = obj.reqARCSend();
			System.out.println( sClip );
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
