#!/bin/sh
MD_HOME=/app/MagicLineMDv2_new
export MD_HOME

javac -cp ${MD_HOME}/MagicLineMD.jar:${MD_HOME}/lib/ARCTRAPI.jar ${MD_HOME}/classes/UsageSample.java

