#!/bin/sh

######### SAMPLE START #########
export JAR=./MagicLineMD.jar
export RECV_COMPLETE_CLASS=com.dreamsecurity.arctr.ArcTRComplete
# ��� �� �� �� XML
export XML_FILE=$1
# �� : S, �� : R
export RS_TYPE=$2

java -version

if [ "$RS_TYPE" = "R" ]; then
	java -classpath $JAR $RECV_COMPLETE_CLASS $XML_FILE
fi
######### SAMPLE END   #########

echo `date` "  " $RS_TYPE "  " $XML_FILE >> result.txt
