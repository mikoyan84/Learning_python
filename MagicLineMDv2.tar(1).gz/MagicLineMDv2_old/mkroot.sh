#!/bin/sh

ROOT_DIR=/software/OLD_ROOT

for dir in "errorlist" "recvlist" "sendlist" "recvcomplete" "sendcomplete"
do
        mkdir -p ${ROOT_DIR}/${dir}
done
