#!/bin/sh
MD_HOME=/edusys/dreamsecurity/MagicLineMDv2/
export MD_HOME

javac -cp ${MD_HOME}/MagicLineMD.jar:${MD_HOME}/lib/ARCTRAPI.jar ${MD_HOME}/classes/UsageSample.java

