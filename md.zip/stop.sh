#!/bin/sh

JAVA_HOME=/usr/bin/java
PATH=${JAVA_HOME}/bin:${PATH}

ID="arctr.path=`pwd`"

for pid in `ps -ef | grep java | grep ${ID} | awk '{ print $2 }'`
do
	echo $pid; kill -9 $pid
done
#jps -l | grep com.dreamsecurity.arctr.ArcTR | cut -d ' ' -f 1 | xargs -n1 kill
