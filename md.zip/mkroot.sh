#!/bin/sh

ROOT_DIR=/edufile/dreamsecurity
for dir in "errorlist" "recvlist" "sendlist" "recvcomplete" "sendcomplete"
do
        mkdir -p ${ROOT_DIR}/${dir}
done
