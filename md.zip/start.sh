#!/bin/sh

export JAVA_HOME=/usr/bin/java

export PATH=${JAVA_HOME}/bin:${PATH}
export LANG=ko_KR.eucKR

#JAVA_OPT='-XX:ParallelGCThreads=4 -XX:+UseParNewGC -Xms128m -Xmx1024m'
JAVA_OPT='-XX:ParallelGCThreads=4 -XX:+UseG1GC -Xms128m -Xmx2048m'
ID="arctr.path=`pwd`"

./stop.sh

JAR=./MagicLineMD.jar
jarsigner -verify ${JAR}

java -version > /edulog/dreamsecurity/console.log
java -D${ID} ${JAVA_OPT} -server -jar ${JAR} >> /edulog/dreamsecurity/console.log 2>&1 &

tail -f /edulog/dreamsecurity/console.log
