#!/bin/sh

./stop.sh

./run.sh
