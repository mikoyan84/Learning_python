#!/bin/sh

#xml파일이 Creation!될 경로에 대한 변수선언(fMenu 옵션값)
OPT0=/edudata/mduser/edufile
OPT1=/software/rms_dir/br
OPT2=/software/rms_dir/ra
OPT3=/software/rms/br
OPT4=/software/rms/ra
OPT5=/app_files/AAG/dcry_trnsfer

#고정된 경로를 메뉴로 지정
echo ""
fMenu()
{
        echo "=========================================================="
        echo "1.1.Select The path where the xml file will be created   "
        echo "=========================================================="
        echo "0. /edudata/mduser/edufile                                "
        echo "1. /software/rms_dir/br                                   "
        echo "2. /software/rms_dir/ra                                   "
        echo "3. /software/rms/br                                       "
        echo "4. /software/rms/ra                                       "
        echo "5. /app_files/AAG/dcry_trnsfer                            "
        echo "6. Direct input(Enter absolute path)                      "
        echo "=========================================================="
}

#메뉴에 대한 행위를 지정
while  :
do
        fMenu
        echo ""
        echo "Choose your option.(Menu:h, Exit:q): "
#MenuNo에 대한 입력값에 대한 행위 지정 (case문 사용)
        read MenuNo
        case "$MenuNo" in
                "q" | "quit" ) echo "exit."
                        break ;;
                "h" ) fMenu ;;
                "0" ) echo "$OPT0/sendlist/ Creation!" 
			echo "$OPT0" > ./locate.temp
			break;;
                "1" ) echo "$OPT1/sendlist/ Creation!" 
			echo "$OPT1" > ./locate.temp
			break;;
                "2" ) echo "$OPT2/sendlist/ Creation!" 
			echo "$OPT2" > ./locate.temp
			break;;
                "3" ) echo "$OPT3/sendlist/ Creation!" 
			echo "$OPT3" > ./locate.temp
			break;;
                "4" ) echo "$OPT4/sendlist/ Creation!" 
			echo "$OPT4" > ./locate.temp
			break;;
                "5" ) echo "$OPT5/sendlist/ Creation!" 
			echo "$OPT5" > ./locate.temp
			break;;
                "6" ) read OPT6 
			echo "$OPT6/sendlist Creation!"
			echo "$OPT6" > ./locate.temp
			break;;
 		"7" ) echo "7. ";;
		*   ) echo "Wrong input option. ";;
       esac

done

#입력값을 변수 fName로 지정
echo "=========================================================="
echo "1.Insert the test file name please                        "
echo "=========================================================="
read fName
echo "$fName" > ./fName.temp

#입력값을 변수 ip로 지정
echo ""

echo "=========================================================="
echo "2.Insert the destination IP please                        "
echo "=========================================================="
read ip
echo "$ip" > ./ip.temp

echo ""
echo "=========================================================="
echo "3.Insert the destination PORT please                      "
echo "=========================================================="
read port
echo "$port" > ./port.temp

#입력값을 변수 dummy로 지정
echo ""
echo "=========================================================="
echo "4.Insert the amount of dummy files please                 "
echo "=========================================================="
read dummy
echo "$dummy" > ./dummy.temp


loc=$(<./locate.temp)
fName2=$(<./fName.temp)

sh ./xml.dat| tee $loc/sendlist/$fName2.xml 
sh ./xml.dat| tee $loc/sendlist/$fName2.xml 

#makexml.dat의 ip입력값을 변수로 지정
var=$(cat ./ip.temp)
#makexml.dat의 port입력값을 변수로 지정
var1=$(cat ./port.temp)
#makexml.dat의 경로 입력값을 변수로 지정
var2=$(cat ./locate.temp)
#makexml.dat의 더미파일 개수 입력값을 변수로 지정
var3=$(cat ./dummy.temp)
#makexml.dat의 파일명 입력값을 변수로 지정
var4=$(cat ./fName.temp)

#입력 내용 확인
echo "1. Your input IP is:  ${var}"
echo "2. Your input PORT is: ${var1}"
echo "3. Your choose locate is: ${var2}"
echo "4. Your input amount of files: ${var3}"
echo "5. Your input file name is: ${var4}"

rm -Rf ./*.temp




