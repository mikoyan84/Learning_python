#!/bin/sh

export JAVA_HOME=/usr/bin/java
export PATH=${JAVA_HOME}/bin:${PATH}
export LANG=ko_KR.eucKR
export ARCTR_HOME=/software/MagicLineMDv2

#JAVA_OPT='-d64'

java ${JAVA_OPT} -cp ${ARCTR_HOME}/classes:${ARCTR_HOME}/lib/ARCTRAPI.jar UsageSample
