#!/bin/sh

#변수 영역
#makexml.sh의 ip입력값을 변수로 지정
var=$(<./conf/ip.temp)
#makexml.sh의 port입력값을 변수로 지정
var1=$(<./conf/port.temp)
#makexml.sh의 경로 입력값을 변수로 지정
var2=$(<./conf/locate.temp)
#makexml.sh의 더미파일 개수 입력값을 변수로 지정
var3=$(<./conf/count.temp)
#makexml.sh의 파일명 입력값을 변수로 지정
var4=$(<./conf/fName.temp)
#makexml.sh의 파일사이즈 입력값을 변수로 지정
var5=$(<./conf/fSize.temp)
#file creation time
var6=`date +"%Y%m%d%I%M%S"`
#ARCTR
ARCTR=/app/was/work/MagicLineMDv2


rm -Rf $var2/$var4/

find $var2 -type f -exec rm -Rf {} \;

rm -Rf ${ARCTR}/data/*
