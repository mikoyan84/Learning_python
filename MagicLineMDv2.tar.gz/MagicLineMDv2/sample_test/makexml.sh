#!/bin/sh

echo "112.7.128.141"  > ./conf/ip.temp
echo "9610" > ./conf/port.temp
echo "/app/NEW_ROOT" > ./conf/locate.temp
echo "1" > ./conf/count.temp
echo "22335533" > ./conf/fName.temp
echo "100" > ./conf/fSize.temp

##makexml.sh의 ip입력값을 변수로 지정
#var=$(cat ./conf/ip.temp)
##makexml.sh의 port입력값을 변수로 지정
#var1=$(cat ./conf/port.temp)
##makexml.sh의 경로 입력값을 변수로 지정
#var2=$(cat ./conf/locate.temp)
##makexml.sh의 더미파일 개수 입력값을 변수로 지정
#var3=$(cat ./conf/count.temp)
##makexml.sh의 파일명 입력값을 변수로 지정
#var4=$(cat ./conf/fName.temp)
##makexml.sh의 파일사이즈 입력값을 변수로 지정
#var5=$(cat ./conf/fSize.temp)
#
##입력 내용 확인
#loc=$(<./conf/locate.temp)
#fName2=$(<./conf/fName.temp)

sh ./xml.dat | tee $loc/sendlist/$fName2.xml 
#sh ./xml.dat | tee $loc/sendlist/$fName2.xml 


echo "done"
