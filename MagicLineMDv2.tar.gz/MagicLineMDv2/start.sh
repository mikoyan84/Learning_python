#!/bin/sh

export JAVA_HOME=/usr/bin/java

export PATH=${JAVA_HOME}/bin:${PATH}
export LANG=ko_KR.utf8

JAVA_OPT='-XX:ParallelGCThreads=4 -XX:+UseParNewGC -Xms128m -Xmx2048m'
#JAVA_OPT='-XX:ParallelGCThreads=4 -XX:+UseG1GC -Xms128m -Xmx2048m'
ID="arctr.path=`pwd`"

./stop.sh

JAR=./MagicLineMD.jar
jarsigner -verify ${JAR}

java -version > ./console.log
java -D${ID} ${JAVA_OPT} -server -jar ${JAR} >> ./console.log 2>&1 &

tail -f ./console.log
